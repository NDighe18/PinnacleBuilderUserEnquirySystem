﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcessLayer.Models
{
    public class UserDetailDbContext:DbContext
    {
        public UserDetailDbContext(DbContextOptions<UserDetailDbContext> options) : base(options) { }
        
        public DbSet<UserDetail> UserDetails { get; set; }
        public DbSet<AdminUser> AdminUsers { get; set; }
    }
}
