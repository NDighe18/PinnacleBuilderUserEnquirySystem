﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcessLayer.Models
{
    public class UserDetail
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(35)]
        [Required]
        public string FirstName { get; set; }

        [MaxLength(35)]
        [Required]
        public string LastName { get; set; }

        [MaxLength(50)]
        [EmailAddress]
        public string EmailId { get; set; }

        [MaxLength(15)]
        public string Max_Budget { get; set; }

        [MaxLength(10)]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Phone number must be 10 digits")]
        public string Phone { get; set; }

        [MaxLength(35)]
        public string Location { get; set; }

        [MaxLength(35)]
        public string Property_Type { get; set; }

    }
}
