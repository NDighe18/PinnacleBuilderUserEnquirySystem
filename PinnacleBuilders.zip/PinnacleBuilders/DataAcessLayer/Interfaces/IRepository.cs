﻿using DataAcessLayer.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcessLayer.Interfaces
{
    public interface IRepository
    {
        public Task<bool> Register(AdminUser newadmin);
        public Task<AdminUser> ValidateAdminUser(string email, string password);

        public Task<bool> AddUserDetail(UserDetail userDetail);

        public Task<bool> EditUserDetail(UserDetail userDetail);

        public Task<IList<UserDetail>> GetUsersList();

        public Task<UserDetail> GetUser(int id);
    }
}
