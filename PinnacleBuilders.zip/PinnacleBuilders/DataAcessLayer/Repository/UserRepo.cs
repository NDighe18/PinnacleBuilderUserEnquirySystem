﻿using DataAcessLayer.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcessLayer.Repository
{
    public class UserRepo : IRepository
    {
        public readonly Models.UserDetailDbContext _context;

        public UserRepo(Models.UserDetailDbContext context)
        {
            _context = context;

        }

        public async Task<bool> Register(Models.AdminUser newadmin)
        {
            await _context.AdminUsers.AddAsync(newadmin);
            int rows = await _context.SaveChangesAsync();
            return rows > 0;
        }

        public async Task<Models.AdminUser> ValidateAdminUser(string email, string password)
        {
            return await _context.AdminUsers.FirstOrDefaultAsync(x=> x.EmailId==email && x.Password==password );
            
        }

        public async Task<bool> AddUserDetail(Models.UserDetail userDetail)
        {
            if(userDetail == null)
            {
                throw new ArgumentNullException(nameof(userDetail));
            }
            await _context.UserDetails.AddAsync(userDetail);
            int rows = await _context.SaveChangesAsync();
            return rows > 0;
        }

        public async Task<bool> EditUserDetail(Models.UserDetail userDetail)
        {
            if(userDetail == null)
            {
                throw new ArgumentNullException(nameof(userDetail));
            }
            _context.UserDetails.Update(userDetail);
            int rows = await _context.SaveChangesAsync();
            return rows > 0;
        }

        public async Task<IList<Models.UserDetail>> GetUsersList()
        {
            return await _context.UserDetails.ToListAsync();
        }

        public async Task<Models.UserDetail> GetUser(int id)
        {
            return  await _context.UserDetails.FindAsync(id);
        }
    }
}
