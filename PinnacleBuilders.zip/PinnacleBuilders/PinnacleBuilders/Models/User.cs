﻿using System.ComponentModel.DataAnnotations;

namespace PinnacleBuilders.Models
{
    public class User
    {
        [Key]
        public int Id { get; set; }

        [MaxLength(35)]
        [Required]
        public string FirstName { get; set; }

        [MaxLength(35)]
        [Required]
        public string LastName { get; set; }

        [MaxLength(50)]
        [Required]
        [EmailAddress]
        public string EmailId { get; set; }

        [MaxLength(15)]
        public string Max_Budget { get; set; }

        [MaxLength(10)]
        [Required]
        [StringLength(10, MinimumLength = 10, ErrorMessage = "Phone number must be 10 digits")]
        public string Phone { get; set; }

        [MaxLength(35)]
        [Required]
        public string Location { get; set; }

        [MaxLength(35)]
        [Required]
        public string Property_Type { get; set; }
    }
}
