﻿using System.ComponentModel.DataAnnotations;

namespace PinnacleBuilders.Models
{
    public class Admin
    {
        [Key]
        [Required]
        [EmailAddress]
        public string EmailId { get; set; }

        [Required]
        [MaxLength(15)]
        public string Password { get; set; }
    }
}
