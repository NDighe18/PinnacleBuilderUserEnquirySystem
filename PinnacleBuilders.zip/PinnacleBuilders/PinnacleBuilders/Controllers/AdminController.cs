﻿using DataAcessLayer.Interfaces;
using DataAcessLayer.Models;
using Microsoft.AspNetCore.Mvc;
using PinnacleBuilders.Models;
using System.Threading.Tasks;

namespace PinnacleBuilders.Controllers
{
    public class AdminController : Controller
    {

        public readonly IRepository _repository;

        public AdminController(IRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
           var users = await _repository.GetUsersList();
           return View(users);
        }

        [HttpGet]

        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Register(PinnacleBuilders.Models.Admin newAdmin)
        {
            if (ModelState.IsValid)
            {
                DataAcessLayer.Models.AdminUser admin = new DataAcessLayer.Models.AdminUser()
                {
                    EmailId = newAdmin.EmailId,
                    Password = newAdmin.Password
                };

                bool isRegistered = await _repository.Register(admin);
                if (isRegistered)
                {
                    return RedirectToAction("Login");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Registration failed. Please try again.");
                }
            }
            return View();

        }


        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Login(AdminUser adminUser)
        {
            if (ModelState.IsValid)
            {
                var admin = await _repository.ValidateAdminUser(adminUser.EmailId, adminUser.Password);
                if (admin != null)
                {

                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid email or password.");
                }
            }
            return View();
        }

        [HttpGet]

        public async Task<IActionResult> Create()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Create(UserDetail userDetail)
        {
            if (ModelState.IsValid)
            {
                bool isAdded = await _repository.AddUserDetail(userDetail);
                if (isAdded)
                {
                    return RedirectToAction("Index");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Failed to add user detail. Please try again.");
                }
            }
            return View();
        }

        [HttpGet]

        public async Task<IActionResult> Edit(int id)
        {
            var userDetail = await _repository.GetUser(id);
            if (userDetail == null)
            {
                return NotFound();
            }
            return View(userDetail);
        }

        [HttpPost]

        public async Task<IActionResult> Edit(User user)
        {
            if (!ModelState.IsValid)
            {
                return View(user);
            }

            DataAcessLayer.Models.UserDetail updatedUser = new DataAcessLayer.Models.UserDetail()
            {
                Id = user.Id,
                FirstName = user.FirstName,
                LastName = user.LastName,
                EmailId = user.EmailId,
                Max_Budget = user.Max_Budget,
                Phone = user.Phone,
                Location = user.Location,
                Property_Type = user.Property_Type
            };
            var result = await _repository.EditUserDetail(updatedUser);
            if (result)
            {
                return RedirectToAction("Index");
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Failed to update user detail. Please try again.");
                return View(user);
            }
        }
    }
}
